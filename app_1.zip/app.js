let count = 0;
for(let i = 0; i < 50; i++){
  count += 1;
  console.log(count)
  if(count == 50) {
    console.log('今' + count + '回ループしました。')
    alert(count + '回カウントが終わりました。')
  } else if(((count % 10) == 0) && ((count % 4) == 0)) {
    console.log('4で割れる数です。' + count)
    console.log('今' + count + '回ループしました。')
  } else if((count % 10) == 0) {
    console.log('今' + count + '回ループしました。')
  } else if((count % 4) == 0) {
    console.log('4で割れる数です。' + count)
  }
}